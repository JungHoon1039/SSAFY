<template>
  <footer>
    <ul class="footer-list">
      <li><a href="#">개인정보처리방침</a></li>
      <li><a href="#">이용약관</a></li>
      <li><a href="#">오시는길</a></li>
      <li>Created by the SSAFY team &middot; &copy; 2022</li>
    </ul>
  </footer>
</template>

<script setup></script>

<style scoped></style>
