<template>
  <div class="container">
    <br />
    <div>
      <h4>
        <RouterLink to="/product/" class="router-menu">상품목록</RouterLink>
      </h4>
      <h4>
        <RouterLink to="/product/create" class="router-menu"
          >상품등록</RouterLink
        >
      </h4>
    </div>
    <br />
  </div>
</template>

<script setup></script>

<style scoped></style>
