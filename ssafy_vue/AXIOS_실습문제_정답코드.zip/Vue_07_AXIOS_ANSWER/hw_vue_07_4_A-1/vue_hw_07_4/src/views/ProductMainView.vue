<template>
  <div class="container">
    <RouterView />
  </div>
</template>

<script setup></script>

<style scoped></style>
