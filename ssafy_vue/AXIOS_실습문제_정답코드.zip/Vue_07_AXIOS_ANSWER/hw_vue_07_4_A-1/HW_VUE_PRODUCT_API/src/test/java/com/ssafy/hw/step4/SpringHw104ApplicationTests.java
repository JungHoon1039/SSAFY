package com.ssafy.hw.step4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHw104ApplicationTests {

	@Test
	void contextLoads() {
	}

}
