package com.ssafy.hw.model.dao;

import com.ssafy.hw.model.dto.User;

public interface UserDao {
	User getUserById(String id);
}
