package com.ssafy.hw.model.service;

import com.ssafy.hw.model.dto.User;

public interface UserService {
	User getUserById(String id);
}
