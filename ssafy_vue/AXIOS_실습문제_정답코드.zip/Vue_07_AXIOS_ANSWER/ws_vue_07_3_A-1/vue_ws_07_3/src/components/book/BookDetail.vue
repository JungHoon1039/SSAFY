<template>
  <div>
    <ViewDetail />
  </div>
</template>

<script setup>
import ViewDetail from "@/components/book/include/ViewDetail.vue";

const components = {
  ViewDetail,
};
</script>

<style scoped></style>
