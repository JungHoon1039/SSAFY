<template>
  <div>
    <WriteForm type="create" />
  </div>
</template>

<script setup>
import WriteForm from "@/components/book/include/WriteForm.vue";

const components = {
  WriteForm,
};
</script>

<style scoped></style>
