<template>
  <div class="about-container">About SSAFY 도서 관리 시스템</div>
</template>

<script setup></script>

<style scoped>
.about-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  font-size: 1.5em;
  font-weight: bold;
  background-color: #e3e3e3;
}
</style>
