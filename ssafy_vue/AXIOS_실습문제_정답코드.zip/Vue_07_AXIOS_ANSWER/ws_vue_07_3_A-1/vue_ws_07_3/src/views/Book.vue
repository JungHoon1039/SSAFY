<template>
  <div class="book-container">
    <RouterView />
  </div>
</template>

<script setup></script>

<style scoped>
.book-container {
  padding: 20px;
  background-color: #ffffff;
  border: 1px solid #ddd;
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}
</style>
