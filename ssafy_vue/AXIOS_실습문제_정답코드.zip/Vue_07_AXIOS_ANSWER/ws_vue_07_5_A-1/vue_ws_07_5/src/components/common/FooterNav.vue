<template>
  <footer class="text-center">&copy; SSAFY Corp.</footer>
</template>

<script setup></script>

<style scoped></style>
