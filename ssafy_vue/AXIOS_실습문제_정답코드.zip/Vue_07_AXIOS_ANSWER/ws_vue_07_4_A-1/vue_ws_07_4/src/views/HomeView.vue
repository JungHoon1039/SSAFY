<template>
  <main class="index-main">
    <div class="main-menu">
      <ul>
        <li>
          <RouterLink to="/restaurants/create" class="router-menu"
            >맛집등록</RouterLink
          >
        </li>
        <li>
          <RouterLink to="/restaurants" class="router-menu"
            >맛집리스트</RouterLink
          >
        </li>
      </ul>
    </div>
  </main>
</template>

<script setup></script>

<style scoped></style>
