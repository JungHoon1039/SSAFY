<template>
  <div class="container">
    <br />
    <div class="text-center">
      <h1>{{ message }}</h1>
    </div>
    <br />
  </div>
</template>

<script setup>
const message = "자동차 정보 사이트에 오신것을 환영합니다.";
</script>

<style>
.text-center {
  text-align: center;
}
</style>
