package com.ssafy.ws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WsVueCarApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
