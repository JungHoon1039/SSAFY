package com.ssafy.ws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WsVueMovieApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(WsVueMovieApiApplication.class, args);
	}

}
