package com.ssafy.ws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WsVueMovieApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
